/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project5;

import java.util.ArrayList;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tazaki
 */
public class OddEven implements Runnable{

   
    boolean pause=true;
    private int id;
    private int n;
    private int p;
    ArrayList<Integer> mainList;   
    ArrayList<Integer> groups;
    ArrayList<Integer> sublist;
    ArrayList<Integer> sublist1;
    ArrayList<Integer>  duplicate;
    ArrayList<Integer> finalList;
    
   
    private CyclicBarrier barrier1;
    private static volatile ArrayList<Integer> sharedEven=new ArrayList<>();

    
    public OddEven(ArrayList<Integer> n, int p,  CyclicBarrier barrier1, int id){
        this.n=n.size();
        this.p=p; 
        this.mainList=n;
        groups=new ArrayList<>();
        sublist=new ArrayList<>();
        sublist1=new ArrayList<>(); 
        finalList=new ArrayList<>();
        this.duplicate=n;
        this.barrier1=barrier1;
        this.id=id;
       
       
    }    
        
    
    public void oddEvenPar() throws InterruptedException, BrokenBarrierException{
         
        //OddEven.id=(int) Thread.currentThread().getId();
         heapSort();
         long partner;
         
         
         
         
         Thread.sleep(500);
         barrier1.await();
         
         for(int phase=0;phase<p;phase++){
           ///Thread.sleep(500);            
                
             partner= compute_partner(phase, (/*Thread.currentThread().getId()-9)*/this.id));
                                    
             if(partner!=-1){
                 //send my keys
                 //System.out.println("this is thread: "+(getId())+" and partner is: "+ (partner));
                 sendKeys(); 
                 
                 
                 if(phase==0){
                 receiveKeys(partner, /*Thread.currentThread().getId()*/this.id);
                 }else{
                     
                     receiveKeys1(partner, /*Thread.currentThread().getId()*/this.id);
                 }
                 Thread.sleep(500);
                 if(phase%2==0){
                 barrier1.await();
                 sharedEven.clear();
                 }
                
                 finalList=merge(sublist, sublist1);
                     
                 //barrier1.await();
                 //sharedEven=finalList;
                 
                 System.out.println("phase: "+phase+"  thread: "+this.id+"  partner: "+partner+" mergedlist: "+sharedEven+finalList+" left: "+sublist+" right:"+sublist1);
                  
                 //System.out.println(shared);
                 
                 if(/*Thread.currentThread().getId()*/this.id<partner){
                     //keep smaller keys
                    
                     
                     int j=finalList.size()/2;
                     for(int i=0; i<j;i++){
                         groups.add(finalList.get(0));
                         finalList.remove(0);
                     }
                     //sublist1=finalList;
                     finalList.clear();
                     sublist.clear();
                     sublist1.clear();
                    
                 }else{
                     //keep larger keys
                     
                    
                     int j=finalList.size()/2;
                     int k=finalList.size();
                     for(int i=j;i<k;i++){
                         groups.add(finalList.get(j));
                         finalList.remove(j);
                     }
                     //sublist1=finalList;
                     finalList.clear();
                     sublist.clear();
                     sublist1.clear();
                     
                 }
                 
                 System.out.println("phase :"+phase+" thread: "+/*Thread.currentThread().getId()*/this.id+" "+groups+"  "+finalList);
             }
             
             
             
            if(phase%2==0){
                Thread.sleep(75);
                barrier1.await();
                for(int i=0; i<p/*+9*/;i++){
                 
                 if(this.id!=i){
                    
                     
                         Thread.sleep(600);
                     
                 }else{
                     
                     sharedEven.addAll(groups);
                    
                 }
              }
            }else{
                
                Thread.sleep(75);
                barrier1.await();
                int j=0;
                for(int i=(int)(/*Thread.currentThread().getId()-9*/this.id)*(n/p);i<(int)(/*Thread.currentThread().getId()-9*/this.id)*(n/p)+groups.size();i++){
                    sharedEven.set(i, groups.get(j));
                    j++;
                }
            }
 
             Thread.sleep(500);
             barrier1.await(); 
            System.out.println("shared data for thread: "+Thread.currentThread().getId()+sharedEven);
                         
         }   
    }
    
    @Override
    public void run() {       
        int count1=0;
            
        
      
       
                                for(int j=1; j<=p;j++){
                for(int i=((j*(n/p))-n/p); i<(j*n/p);i++){
                    if(this.id==j-1){
                        groups.add(mainList.get(i*(j-count1)));
                    }
                }
                count1++;         
        }
          
            
        
           
        
        
        
        
        try{
        oddEvenPar();
        } catch (InterruptedException | BrokenBarrierException ex) {
            Logger.getLogger(OddEven.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            barrier1.await();
        } catch (InterruptedException | BrokenBarrierException ex) {
            Logger.getLogger(OddEven.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("threadId: "+this.id );
    }
    
    public long compute_partner(int phase, int id){
        
        long partner;
        
        if(phase%2==0){
            if(id%2==0){
                partner= id+1/*+9*/;
            }else{
                partner=id-1/*+9*/;
            }
        }else{
            if(id%2==0){
                partner=id-1/*+9*/;
            }else{
                partner=id+1/*+9*/;
            }
        }
        if(partner==/*9*/-1||partner==p/*+9*/){
            partner=-1;
        }        
        return (partner);
        
    }
     
    public void sendKeys(){      
        
            int j=groups.size();
            for (int i =0;i<j;i++) {
                sublist.add(groups.get(0));
                groups.remove(0);
        }       
    }
    
    public void receiveKeys(long partner, long id){
        int count1=0;
            if(this.id==id){
                for(int i=(int)(partner/*-9*/)*(n/p); i<((partner/*-8*/+1)*(n/p));i++){            
                         sublist1.add(mainList.get(i));
        
                }
                if(this.id==p-1){
                    
                }
                
                //if(partner==n/p&&)
                insertionSort();
            }     
    }
    
    
    
     void insertionSort(){
          int key;
        int i, j;
        
         for( i=1; i<sublist1.size(); i++ ){
                key=sublist1.get(i);
                j=i;
                while(j>0 && (sublist1.get(j-1).compareTo(key)>0)){
                    sublist1.set(j, sublist1.get(j-1));
                    j--;
                }
                sublist1.set(j, key);
            }
     }
     
     public void heapSort(){
        int size = groups.size() - 1;
        buildHeap(groups, size);
        for (int i = groups.size() - 1; i >= 1; i--) {
            exchange(0, i, groups);
            size--;
            maxHeapify(groups, 0, size);
        }
    }

  
    private static <String extends Comparable<? super String>> void maxHeapify(ArrayList<String> list, int i, int size) {
        int largest = i; // initialise largest to index.

        int left = findLeft(i);
        int right = findRight(i);

        if (left <= size && list.get(left).compareTo(list.get(i)) >= 1) {
            largest = left;
        }

        if (right <= size && list.get(right).compareTo(list.get(largest)) >= 1) {
            largest = right;
        }
        if (largest != i) {
            exchange(i, largest, list);
            maxHeapify(list, largest, size);
        }
    }

   
    private static <String extends Comparable<? super String>> void buildHeap(ArrayList<String> list, int heapSize) {
        long startTime=System.nanoTime();
        int start = (int) Math.floor((heapSize / 2));
        for (int i = start; i >= 0; i--) {
            maxHeapify(list, i, heapSize);
        }
    }

    private static <String extends Comparable<? super String>> void exchange(int i, int largest, ArrayList<String> list){
        String temp = list.get(largest);
        list.set(largest, list.get(i));
        list.set(i, temp);
    }

    private static int findLeft(int i) {return (i << 1) ^ 1;}

    private static int findRight(int i) {return (i<< 1) + 2;}
     
    private static ArrayList<Integer> merge(ArrayList<Integer> left, ArrayList<Integer> right)
    {
    ArrayList<Integer> merged = new ArrayList<>();
    int i = 0;
    int l = 0;
    int r = 0;
  
    while (l < left.size() && r < right.size())
           {
              if ((left.get(l)).compareTo(right.get(r)) < 0)
              {
                 merged.add(left.get(l));
                 l++;
              }
              else
              {
                 merged.add(right.get(r));
                 r++;
              }
              i++;
           }
              while (l < left.size())
           {
              merged.add(left.get(l));
              l++;
              i++;
           }
           while (r < right.size())
           {
              merged.add(right.get(r));
              r++;
                  i++;
           }

    return merged;
  }

    private void receiveKeys1(long partner, long id) {
         if(this.id==id){
                for(int i=(int)(partner/*-9*/)*(n/p); i<((partner/*-8*/+1)*(n/p));i++){            
                         sublist1.add(sharedEven.get(i));
        
                }
                //insertionSort();
                 }
    }    
    
}
