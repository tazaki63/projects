/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project5;

import java.util.ArrayList;
import java.util.Random;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;


/**
 *
 * @author Tazaki
 */
public class Project5 {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     * @throws java.util.concurrent.BrokenBarrierException
     */
    public static void main(String[] args) throws InterruptedException, BrokenBarrierException {
        
        
        int p=Runtime.getRuntime().availableProcessors();
        int n=1200;
        
       
        CyclicBarrier barrier1= new CyclicBarrier(p);
        
        
        
        System.out.println("number of processors: "+p+" and n: "+n+" n/p: "+n/p);
        System.out.println("the sharedEven is the sorted list");
        
        
         ArrayList<Integer> list=new ArrayList<>();
        Random rand=new Random();
        int newInt;
        for(int i=0; i<n;i++){
            newInt=rand.nextInt(100);
            list.add(newInt);
        }
        
        System.out.println(list);

        //OddEven temp;
        
        int threadId=0;
        for (int i = 0; i < p; i++) {
        OddEven c = new OddEven(list, p, barrier1, threadId);
        Thread thread = new Thread(c);
        thread.start();
        threadId++;
        
    }
        //barrier.await();
        
      
         
     
        
        
    }
    
}
